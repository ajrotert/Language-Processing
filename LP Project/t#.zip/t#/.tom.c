#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int main() {
int minx = 0;
int maxx = 10;
int miny = 0;
int maxy = 10;
float scaley;
float scalex;
float x1, x2, x3, x4, x0, root1, root2, mid, i1, root3, i2, i3, f1, g1, h1, R1, S1, T1, U1, j1, k1, L1, M1, N1, P1;;
int least;
float x;

minx = -5;
maxx = 5;
miny = -5;
maxy = 5;
printf("Example 1\n");
float a;
a = 10;
if( a == 10) {
if( a == 10) {
scanf("%f", &a);
}
}
scaley = (maxy - miny * 1.0) / 20;
scalex = (maxx - minx * 1.0) / 40;
for(float i = maxy; i >= miny; i -= scaley) {
printf("%10.1f|", i);
for(x = minx; x <= maxx; x += scalex) {
float yValue;
yValue = a * pow(x, 2);
if(yValue >= i && yValue < (i + scaley) )
printf("#");
else
printf(" ");
}
printf("\n");
}

while(maxx%5 != 0)maxx++;
while(minx%5 != 0)
minx--;
scalex = (maxx-minx*1.0)/20;
least = ( (int)(log10(abs(minx))+1) > (int)(log10(abs(maxx))+1) ) ? (int)(log10(abs(minx))+1) : (int)(log10(abs(maxx))+1);
for(int i = least; i > 0; i--) {
printf("          ");
for(float j = minx; j <= maxx; j += scalex) {
char toprint;
if(j == (int)j)
toprint = '0' + ((int)(abs(j) / pow(10, i-1))) % 10;
else
toprint = ' ';
printf(" %c", toprint);
}
printf("\n");
}
printf("%f", a);
printf("\nDone\n");


return 0;
}
